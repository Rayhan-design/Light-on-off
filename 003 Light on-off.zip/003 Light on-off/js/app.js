"use strict"

function lightBtn(match){
	let title = document.getElementById('title');

	let pic;
	for(let lightNumber = 1; lightNumber <= 5; lightNumber++){
		if(match == 0){
			pic = '../image/pic_bulboff.gif';
			title.innerText = 'Light Off';
		}else{
			pic = '../image/pic_bulbon.gif';
			title.innerText = 'Light On';
		}

		let light = document.getElementById('light-'+(lightNumber));
		light.src = pic;
	}
}